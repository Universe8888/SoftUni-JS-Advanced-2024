// Assume this function is part of your application's session management.
function isUserAuthenticated() {
    // This should check if the user is logged in and return true or false.
    // Typically, this involves checking if there's a valid user token.
    return localStorage.getItem('userToken') !== null;
}

// Function to determine if the logged-in user is the author of the idea.
function isUserTheAuthor(ideaOwnerId) {
    const userId = localStorage.getItem('userId'); // Assuming userId is stored in localStorage upon login.
    return ideaOwnerId === userId;
}

// Function to fetch idea details from the backend.
async function fetchIdeaDetails(ideaId) {
    const response = await fetch(`http://localhost:3000/data/ideas/${ideaId}`);
    if (response.ok) {
        return response.json();
    }
    throw new Error('Failed to fetch idea details');
}

// Function to delete an idea. Implement this as needed.
async function deleteIdea(ideaId) {
    // This function should make an API call to delete the idea
    // and then probably refresh the page or redirect the user.
}

// Main function to setup and display the idea details.
async function showIdeaDetails(ideaId) {
    try {
        const idea = await fetchIdeaDetails(ideaId);
        const detailsSection = document.getElementById('idea-details-section');
        
        // Construct the HTML for the idea details view.
        // Include the 'Delete' button only if the user is authenticated and is the author of the idea.
        detailsSection.innerHTML = `
            <img class="det-img" src="${idea.img}" />
            <div class="desc">
                <h2 class="display-5">${idea.title}</h2>
                <p class="idea-description">${idea.description}</p>
            </div>
            ${isUserAuthenticated() && isUserTheAuthor(idea._ownerId) ? `<button class="btn detb" onclick="deleteIdea('${idea._id}')">Delete</button>` : ''}
        `;

        // You might want to show this section if it's hidden
        detailsSection.style.display = 'block';
    } catch (error) {
        console.error('Error fetching idea details:', error);
        // Handle error (show error message, log to monitoring, etc.)
    }
}

