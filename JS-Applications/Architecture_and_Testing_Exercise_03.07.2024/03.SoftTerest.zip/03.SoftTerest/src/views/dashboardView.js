async function renderDashboard() {
    const ideas = await fetchIdeas(); // Implement fetchIdeas to call the backend correctly.
    const ideasContainer = document.getElementById('dashboard-holder');
    ideasContainer.innerHTML = ''; // Clear existing content.
    ideas.forEach(idea => {
        const ideaHTML = `
            <div class="card overflow-hidden current-card details">
                <div class="card-body">
                    <p class="card-text">${idea.title}</p>
                </div>
                <img class="card-image" src="${idea.img}" alt="${idea.title}">
                <a class="btn" onclick="showIdeaDetails('${idea._id}')">Details</a>
            </div>
        `;
        ideasContainer.innerHTML += ideaHTML;
    });
}