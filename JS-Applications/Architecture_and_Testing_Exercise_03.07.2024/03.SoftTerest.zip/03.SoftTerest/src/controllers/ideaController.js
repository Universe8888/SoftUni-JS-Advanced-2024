
async function createIdea(title, description, imageURL) {
    const body = { title, description, imageURL };
    try {
        const result = await makeRequest('http://localhost:3000/data/ideas', 'POST', body);
        // If creation is successful, redirect to dashboard
        showView('dashboard-view');
        // Optionally, you can call fetchIdeas here to refresh the list of ideas.
    } catch (error) {
        console.error('Failed to create idea:', error);
        alert('Failed to create idea: ' + error.message);
    }
}

async function fetchIdeas() {
    try {
        const ideas = await makeRequest('http://localhost:3000/data/ideas', 'GET');
        // Clear existing ideas
        const container = document.getElementById('ideas-container');
        container.innerHTML = '';
        // Append each idea to the container
        ideas.forEach(idea => {
            const ideaElement = document.createElement('div');
            ideaElement.innerHTML = `
                <div class="card overflow-hidden current-card details" style="width: 20rem; height: 18rem;">
                    <div class="card-body">
                        <p class="card-text">${idea.title}</p>
                    </div>
                    <img class="card-image" src="${idea.imageURL}" alt="Card image cap">
                    <a class="btn" href="#" onclick="showIdeaDetails('${idea._id}')">Details</a>
                </div>
            `;
            container.appendChild(ideaElement);
        });
    } catch (error) {
        console.error('Failed to fetch ideas:', error);
        alert('Failed to fetch ideas: ' + error.message);
    }
}

async function showIdeaDetails(ideaId) {
    try {
        const idea = await makeRequest(`http://localhost:3000/data/ideas/${ideaId}`, 'GET');
        // Populate the idea details section with the idea data
        const detailsSection = document.getElementById('idea-details-section');
        detailsSection.innerHTML = `
            <div class="some">
                <img class="det-img" src="${idea.imageURL}" />
                <div class="desc">
                    <h2 class="display-5">${idea.title}</h2>
                    <p class="infoType">Description:</p>
                    <p class="idea-description">${idea.description}</p>
                </div>
                <div class="text-center">
                    <a class="btn detb" href="#" onclick="deleteIdea('${idea._id}')">Delete</a>
                </div>
            </div>
        `;
        showView('idea-details-section'); // Assuming this is the ID of the view for displaying details
    } catch (error) {
        console.error('Failed to fetch idea details:', error);
        alert('Failed to fetch idea details: ' + error.message);
    }
}

async function deleteIdea(ideaId) {
    try {
        await makeRequest(`http://localhost:3000/data/ideas/${ideaId}`, 'DELETE');
        // If deletion is successful, refresh the list of ideas or redirect to dashboard
        showView('dashboard-view');
        fetchIdeas(); // Refresh ideas list
    } catch (error) {
        console.error('Failed to delete idea:', error);
        alert('Failed to delete idea: ' + error.message);
    }
}

// Add these functions to the global window object so they can be accessed from HTML
window.ideaController = {
    createIdea,
    fetchIdeas,
    showIdeaDetails,
    deleteIdea
};