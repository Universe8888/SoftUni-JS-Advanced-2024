import { html } from 'https://unpkg.com/lit-html/lit-html.js';

const homeTemplate = () => html`
<section id="home" class="cyberpunk-home">
    <h1 class="hidden">Welcome to the Cyberpunk Dark Market</h1> <!-- This remains for accessibility while visually hidden -->
    <img src="./images/home.png" alt="Cyberpunk Dark Market" class="home-banner" />
    <p class="tagline">We know who you are, we will contact you.</p>
    <nav class="home-nav">
        <a href="/market" class="nav-link">Market</a>
        <a href="/login" class="nav-link">Login</a>
        <a href="/register" class="nav-link">Register</a>
    </nav>
</section>
`;

export async function homeView(context) {
    context.render(homeTemplate());
}
