function getInfo() {
    const stopId = document.getElementById('stopId').value;
    const stopName = document.getElementById('stopName');
    const buses = document.getElementById('buses');
    const url = `http://localhost:3030/jsonstore/bus/businfo/${stopId}`;

    fetch(url)
        .then(response => response.json())
        .then(data => {
            stopName.textContent = data.name;
            buses.innerHTML = '';
            Object.entries(data.buses).forEach(([bus, time]) => {
                const li = document.createElement('li');
                li.textContent = `Bus ${bus} arrives in ${time} minutes`;
                buses.appendChild(li);
            });
        })
        .catch(() => {
            stopName.textContent = 'Error';
            buses.innerHTML = '';
        });
}